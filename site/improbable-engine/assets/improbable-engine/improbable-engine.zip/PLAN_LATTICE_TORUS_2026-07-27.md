# PLAN — Lattice Labs · graph + torus visualisation artwork
2026-07-27 · `~/transmediale` (fresh directory, not a git repo yet)

## What this is

A single-page visualisation artwork in the family of the soulbis `/star` and `/lattice`
instruments, the game42 constellation, and the spellweb graph — built for the
transmediale 2027 **Lattice** theme. A torus lattice carries the five Lattice Labs as
named strands; at its heart sits the **FedWiki Pi knowledge hearth** — the collaborative
knowledgebase whose pages and links feed the living graph woven over the lattice.

The premise: the labs "rethink and test alternatives to technological monocultures of
extraction and surveillance" (Jul 2026 → festival Jan 26–31, 2027). A federated wiki —
small, forkable, self-hosted on a Pi — *is* such an alternative. The artwork shows
knowledge-sharing as structure: the lattice is the program, the graph is the commons.

## The five labs (ground truth, verified 2026-07-27)

| Lab | Steward(s) | Theme |
|---|---|---|
| Playful Misuse (of everyday software) | viola he | reappropriating existing tools; playful relationship to software |
| Obscure Detritus | Alex Declino | AI characters (Commedia dell'Arte) in simulated environments; emergent narrative |
| Minor Indexes | selfservice.studio | situated datasets as community infrastructure against surveillance |
| Reclaiming the Interface | Olia Lialina | interface as staged performance; prototypes, gestures, fictions |
| Solidarity Economies | Sepp Eckenhaussen & Geert Lovink | cooperatives, DAOs, fair payment for art workers |

Program: three phases — bi-weekly online inquiry → collective production → festival
activation in Berlin. ~5 participants per lab.

## Form

- **Torus lattice** — a (p,q) winding lattice on a torus surface, rendered in canvas
  (rotatable, slow ambient drift). Five strands wind the torus, one per lab, each a
  named colour; strand crossings are lattice vertices.
- **Knowledge graph** — FedWiki pages as nodes, page-to-page links as edges, sites as
  clusters. The graph lives *on* the torus surface (nodes seated near the strand whose
  lab-theme they resonate with) with a flat force-graph view as a toggle.
- **The hearth** — the Pi FedWiki hub rendered at the torus centre: warm hearth-gold
  core, the axis everything winds around. Pages flow from hearth to lattice.
- **Register** — dark navy field, glass panels, mono eyebrow labels, serif display
  titles, glow-gem legend chips: the same hand as soulbis `/lattice/index.html`.
  Five lab hues to be chosen against that palette (dataviz skill pass before coding).

## Phases

### 1. Seed (build now)
- `data/labs.json` — the five labs: name, steward, theme, one-line description, hue.
- `README.md` — what the piece is, the Lattice framing, sources.
- Scaffold `index.html` — single-file instrument (no build step), torus lattice with
  the five named strands + hearth core, running on placeholder graph data.

### 2. ★ MITCH'S REVIEW — the localwiki files (open checkpoint)
**This slot is deliberately left open.** The wiki farm at `~/.wiki` has ~25 sites
(guide, atlas, city, grimoire, game42, dtg, timelines, spellbooks…). Before any
harvesting: Mitch walks the localwiki files and decides **which sites and pages
constitute the knowledge hearth for this piece** — what is shared into the artwork,
what stays home. Output of the review: `data/hearth-manifest.json` (list of site dirs /
page slugs, plus any pages to exclude). Nothing is read into the artwork before this
manifest exists. Questions to hold while reviewing:
- Which sites embody "sharing of knowledge" for a transmediale audience?
- Any pages with names/tokens/creds that must never leave the Pi? (leak-audit applies)
- Should the five labs map to five *clusters* of wiki content, or does the wiki enter
  as one undivided hearth?

### 3. Harvest (after manifest)
- `scripts/harvest.mjs` — read the manifested FedWiki JSON (each page = JSON with
  story items + journal; links = `[[…]]` / `reference` items) → `data/graph.json`
  (nodes, edges, clusters, timestamps). Pure read-only; no wiki writes.

### 4. Weave (build)
- Seat the harvested graph on the torus: cluster→strand affinity, journal timestamps
  as ambient pulse (recent edits glow), hover = page title + site, click-through to
  the live localhost wiki page when running locally.
- Toggles: torus ↔ flat graph · strands on/off · per-lab isolation · drift pause.

### 5. Showing (Mitch decides)
- Local review server first. No git init / commit / push / deploy without explicit
  ask (standing rule). Distribution options (static export, guide federation page,
  soulbis sibling) are decisions for later — the guide carries work, and this becomes
  work once it exists.

## Sources
- https://transmediale.de/en/news/lattice-labs (JS-rendered; content verified via
  reposts: on-the-move.org, contemporaryperformance.com, toshareproject.it)
