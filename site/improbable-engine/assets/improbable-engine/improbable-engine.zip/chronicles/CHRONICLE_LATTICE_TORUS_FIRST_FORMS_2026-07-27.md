# CHRONICLE — the Lattice Torus, first forms
2026-07-27 · `~/transmediale` · a guide-style provenance of how this was built, written as it happened

> the codex was a torus all along; it only needed enough sharing to close

## Why this exists

transmediale 2027's theme is **Lattice**; its Lattice Labs (Jul 2026 → festival Jan 26–31 2027)
are five working groups "rethinking and testing alternatives to technological monocultures of
extraction and surveillance." Mitch asked for a visualisation artwork in the family of the
soulbis `/star`, the game42 board, and the spellweb graph — a lattice carrying the five labs
and the FedWiki Pi knowledge hearth, woven from the collaborative knowledgebases.

## The walk so far

**1 · Ground truth.** The transmediale news page is JS-rendered, so the five labs were
verified through the open-call reposts (on-the-move.org, contemporaryperformance.com,
toshareproject.it): Playful Misuse (viola he), Obscure Detritus (Alex Declino), Minor
Indexes (selfservice.studio), Reclaiming the Interface (Olia Lialina), Solidarity
Economies (Eckenhaussen & Lovink).

**2 · First plan.** `PLAN_LATTICE_TORUS_2026-07-27.md` — form, phases, and the
★ checkpoint: Mitch reviews the localwiki files and authors the hearth-manifest before
any wiki content enters the artwork. That checkpoint still stands; the demo below reads
the wiki *live and locally only*, it bakes nothing.

**3 · The geometry study.** Mitch sent the build back to the canon: game42
`GEOMETRY.md` / `MODEL-SYNC.md` / `VISUAL-SPEC.md` and the `/star` instrument. Two
findings became the piece's direction:

- **The torus is the Vertex Codex closed shut.** A 6-bit vertex splits into two 3-bit
  halves → an 8×8 grid; periodic in both directions = a torus. `/lattice` (flat codex),
  `/star` (walkable manifold), and this piece are three seatings of one 64-vertex
  sovereignty lattice — and the torus seating has no boundary row, no privileged corner:
  a lattice with no extraction point, which is the theme performed by the geometry.
- **Five labs + the hearth = six = the stratum-1 basis.** The count lands on the six
  roots exactly (C(6,1) = 6, the load-bearing binding of MODEL-SYNC §4). Each strand
  takes an axis and its game42 hue; the FedWiki hearth lands on **connection** — one of
  the Four Forces, and literally the network axis. The mapping is held as
  **[Conjectural]** until Mitch confirms or reseats it.

**4 · Second plan.** `PLAN_3JS_LATTICE_TORUS_2026-07-27.md` — the Three.js interactive:
single-file instrument like `/star`, vendored Three (offline-able, Pi-able), torus ⇄
codex morph as the signature move, Three-Graphs staging (wiki pages = Knowledge Graph,
links = Promise Graph, walked paths = Trust Graph with a T∫(π) tracer), R(t) ceiling
toggle, build order B1–B6.

**5 · The build begins (this session).** Mitch: *"lets start to build the first forms…
a quick demo thats connected into the wiki i can host locally and view."* Decisions
made at the bench:

- **Vendored `three@0.161.0`** (module build + OrbitControls) out of game42's
  node_modules into `vendor/` — no CDN, the piece must run where the hearth runs.
  (`/star` uses CDN r128 globals; this build goes ES-modules + import map.)
- **The farm speaks on :3030** (`wiki --data ~/.wiki --port 3030 --farm`, vhost style
  `guide.localhost:3030` — read from the wiki-sync skill's own docs).
- **A proxy, not CORS hope.** `serve.mjs` — a zero-dependency node server that serves
  the demo statically and forwards `/wiki/<host>/<path>` to `127.0.0.1:3030` with the
  right Host header. The demo page stays same-origin; the farm needs no CORS
  configuration; nothing ever leaves the machine.
- **`data/wiki-sites.json` is the proto-manifest.** The demo's default site list +
  strand affinities live in one editable file — this is the placeholder the ★ review
  replaces. Live-read only; no harvest file is written.
- **Chronicle opened** (this file) at Mitch's ask: provenance kept in the flow of the
  build, guide-style, the way the sibling repos do.

## Bench notes (appended as the build lands)

- vendor/ seated: three.module.min.js (660 KB) + OrbitControls.js. Import map will bind
  `"three"` → the vendored module so OrbitControls' bare import resolves.
- `data/labs.json` written — six strands with bits 0–5, axis hues from the game42 canon,
  steward names, and a `mappingStatus: CONJECTURAL` flag carried in the data itself.
- `data/wiki-sites.json` written — 15 demo sites with strand affinities, marked in-file
  as the PROTO hearth-manifest awaiting the ★ review.
- `serve.mjs` + `package.json` — `npm run dev` → localhost:4242; `/wiki/<host>/<path>`
  proxies to the farm with the vhost Host header, `*.localhost` only.
- **`index.html` — the instrument, first form.** One file. The load-bearing function is
  `seat(u, v, lift)`: every position exists in BOTH forms — torus
  `((R+(r+lift)cos v)cos u, …, (r+lift)sin v)` and flat codex `((u/τ)·8−4)·CELL …` —
  and the fold slider lerps between them through the game42 smoothstep. Because
  everything (gems, grid, strands, page-stars, link arcs, hearth threads, walk trail)
  seats through that one function, the torus ⇄ codex morph is total: the whole piece
  folds, not just the mesh. Grid seam edges (the u/v wraps) fade out as the codex opens —
  the seam is real on the torus, cut on the flat page.
- 64 gems coloured cool→warm by stratum (popcount/6), the `/star` register. Six strand
  windings `(1,0) (0,1) (1,1) (1,2) (2,1) (1,3)` — distinct so the ribbons read apart;
  logged as aesthetic, not architectural. Latent breath + slow golden drift per game42
  GEOMETRY §5; `prefers-reduced-motion` stills both.
- **First live smoke test: the farm was already burning.** Proxy returned guide.localhost's
  sitemap (32 pages) on the first try. And a gift discovered in the shape of the data:
  **FedWiki sitemaps already carry each page's links** (`links: {slug: hash}`) — so the
  Promise Graph weaves straight from sitemaps, no per-page fetching. `loadWiki` was
  rewritten around this: seat all sites first, then weave links across the whole
  federation (slugs are site-agnostic, so cross-site links land naturally). ~16 requests
  total instead of ~160.
- Z-up fix: the torus lies in the xy-plane, so `camera.up = (0,0,1)` before
  OrbitControls — otherwise orbiting fights the piece's horizon.
- Interactions landed: hover tooltip (title · site · lab · edit age), click = walk
  (trail line + T∫(π) tracer, path-weighted), shift+click opens the live wiki page,
  legend chip isolation, five toggles, fold slider. Recent pages (7 days) pulse.
- Status: **first forms COMPLETE, demo live at localhost:4242** — torus + strands +
  hearth + live wiki constellation, running against the real farm. Not yet done from
  the plan: R(t) ceiling, seal card, URL-hash state, Pi test (B5–B6); the ★ review
  still gates the real manifest.

## Round two — Mitch's first viewing (same day)

Mitch walked the demo and sent back five things; all landed:

- **NAMED: "the lattice lab improbable engine."** Title seated under the transmediale
  eyebrow. (The Hitchhiker's resonance is deliberate — see the autoresearch plan for
  why the engine earns the name.) Footer trimmed to the signature alone.
- **The fold-slider line-spray bug, found by Mitch on first click.** Root cause:
  windings and jittered stars carry angles past τ; the torus trig doesn't care, but the
  flat codex branch of `seat()` seated them **off the board** — the "whole bunch more
  lines." Fix in three parts: `seat()` now wraps u,v into the fundamental domain for
  the codex branch; strand ribbons became LineSegments that skip seam-crossing pairs
  (invisible micro-gaps on the torus, no jump-scribbles on the codex) and quiet to
  ~55% opacity as the codex opens; link arcs now blend their bump radial→vertical with
  the fold so they lift off the page instead of spraying from the origin.
- **Constellations are saveable.** The tracer panel grew ✦ save / clear / ⬇ export and
  a list: a walk is named, kept in localStorage, relit by clicking its name, forgotten
  with ×, and exported (all of them) as `constellations.json`. A trace is now an
  artifact, not a moment.
- **The generative turn.** Mitch: the auto-generation from his agentprivacy farm is the
  amazing part — so the field must open to *anyone's* farm, farms must be able to
  **overlap**, and an agent **autoresearch loop** should connect the dots between them
  into a new visualisation. Two plans written:
  `PLAN_GENERATIVE_HEARTH_2026-07-27.md` (any farm feeds the engine; site-discovery
  checklist as the visitor's manifest moment; lexicon→embedding generative strand
  seating, proposed-not-imposed) and `PLAN_OVERLAP_AUTORESEARCH_2026-07-27.md`
  (two farms as constellation shells on one torus; shared slugs = twin-star filaments,
  FedWiki's fork lineage made literal; the agent loop sweep→connect→propose→verify→emit
  with an **improbability score** — high kinship ÷ prior connectedness — bridges
  rendered in the ceiling's violet, reasons as hover text, read-only always, the
  human accepts a bridge by making the link themselves on their own farm).

## Round three — the Lattice Garden surfaces

Mitch pointed at **mitch.lattice.myth.garden** — his fork subwiki of a 26-page research
corpus at **lattice.myth.garden** ("Lattice Garden"), built 19 Jul: the Lattice ×
Hitchhikers research. Reviewed in-session. The load-bearing findings for THIS build:

- **The Alignment Map's structural claim**: Hitchhikers is *not a sixth component
  asking for stage time* — it is a **candidate edge structure**, the bonds of a lattice
  that currently has "nodes but unspecified bonds." This puts pressure on the engine's
  six-strand seating (hearth as strand #6) — the research says the wiki's role is the
  EDGES. Both readings can coexist (connection is genuinely a root of the sovereignty
  lattice), but the engine's presentation should weight the hearth as bond-maker, and
  the bridge/fork layers as the piece's heart. Decision seated with Mitch.
- **The engine is the exhibit the research already promised.** Shared Lexicon Lattice
  (weaving proposal #2): "the printed or projected artefact at the festival is the link
  structure itself… the visualisation of who forked what from whom **is the exhibit**."
  The improbable engine is that visualisation. Missing piece: **fork-provenance edges**
  (from page journals) — who forked what from whom — alongside sitemap links.
- **Corrected festival facts** (garden is newer than the open-call reposts): theme =
  **Groundstates**, curator **Barbara Cueto**, 40th anniversary, festival **Jan 28–31
  2027** (labs.json said Jan 26–31 — to reconcile; the garden itself carries a
  26–Feb 1 vs 28–31 discrepancy between plan and festival pages, flagged in review).
- mitch.lattice.myth.garden is a **real remote farm** — the generative-hearth plan's
  G1 (remote fetch, no proxy) now has its first live test target.

## Round four — the notebook and the handover

Mitch confirmed write admin on the garden and named the flow: **work weaves into the
local wiki first, then travels to the remote assets folder** — the mitch notebook. Built:

- **`transmediale.localhost` — the notebook site**, seeded with six pages (Welcome ·
  Improbable Engine · Six Strands · Lattice Torus Geometry · Run Your Own Grid ·
  Engine Chronicle), written straight into the farm and verified serving. Added to the
  engine's field on the connection strand — the notebook now appears as stars inside
  the piece it documents.
- **`COLLABORATOR.md`** — the handover contract: quickstart, bring-your-own-farm
  instructions, and a ready prompt for a collaborator's *agent* to stand up a farm from
  their machine ("my grid, not Mitch's"). The invariant stated plainly: **the six
  strands are the instrument and do not change; collaborators bring pages, not axes.**
  `wiki-sites.json`'s note rewritten to the same effect.
- **`share/improbable-engine.zip`** (0.2 MB) — the whole directory bundled: engine,
  vendored three, data, plans, chronicles, COLLABORATOR.md. Destination:
  `mitch.lattice.myth.garden/assets/improbable-engine/` — upload is Mitch's click
  (his login, his site); `share/PAGE_improbable-engine.md` carries the ready-to-paste
  remote page text (conventions honored) plus the upload steps.
- Distribution posture: the engine travels by wiki — page + asset on the mitch subwiki,
  forkable onward through the federation, which is itself the Shared Lexicon Lattice
  mechanism demonstrated once more.

## Round five — the crystals and the publish

- **Five lab crystals landed.** Feedback asked for "a more crystal 5×5 lattice formation
  in the middle… one for each lab." Implemented as **ground-state plaquettes**: five
  5×5 point-and-bond crystals ringing the hearth in the torus void, each standing at
  its strand's azimuth in its lab hue, gently shimmering (phonons — in ground state,
  not frozen) and swaying to face the ring. The hearth is the centre itself, so it
  carries no crystal — the five labs crystallise *around* the commons. This takes the
  garden's Geometry-of-the-Lattice framing literally: a lab is a regular arrangement
  whose collective properties emerge from local coupling. The 5×5 count is held as
  aesthetic-conjectural (cohort-scale resonance, ~5 participants per lab). New
  `crystals` toggle; crystals rise with the hearth over the opened codex; strand
  isolation dims sibling crystals.
- **Mitch seated the Assets item himself** — on the Welcome page of
  mitch.lattice.myth.garden, folder `improbable-engine`, confirmed by reading the page:
  the asset URL all our links already point at is exactly right. Zip rebuilt with the
  crystals (207 KB) awaiting his drop.
- **The publish flow settled**: notebook pages fork upward in the browser (local
  `transmediale.localhost:3030` tab → drag the page flag onto the logged-in
  mitch.lattice.myth.garden tab), which preserves fork provenance in the journals —
  the very lineage the twin-star layer will later render.
## Round six — root-truth pass and the garden seats itself

Mitch asked for a double-check of the garden's root information and a look at how the
localwiki farm reflects into the engine. Read in full: transmediale-2027, groundstates,
lattice-labs (plus the earlier geometry/alignment/proposal pages). Outcomes:

- **Knowledge base corrected.** Festival is **28–31 January 2027 at silent green
  Kulturquartier, Berlin** — labs.json had carried "Jan 26–31" from the older open-call
  reposts. Meta now carries theme (groundstates), curator (Barbara Cueto), RFC 40,
  40th anniversary, and the verified three-phase lab timeline. Lab theme lines
  re-phrased to the garden's own vocabulary (Reclaiming = resisting interface
  dissolution; Minor Indexes = datasets against consolidation, local hold; Solidarity =
  a cohort develops and *inhabits* its own model). Provenance nuance kept in mind: the
  "decentralised system" phrase exists only in CTM's version of the announcement; the
  autumn curatorial statement is the authoritative text (a garden verify-task).
- **The garden's own critical note argues for the engine**: if the decentralised-system
  framing persists, the five labs must not be presented serially on one stage — a
  torus with no privileged position is that requirement, in geometry.
- **CORS probe → the garden seats itself.** `Access-Control-Allow-Origin` reflects the
  engine's origin, so remote FedWikis are fetchable directly from the page. Transport
  split shipped (G1 of the generative-hearth plan, early): sites with a `url` fetch
  direct, `*.localhost` keeps the proxy; shift+click opens remote pages at their real
  address. **lattice.myth.garden and mitch.lattice.myth.garden are now in the field**
  on the connection strand — the research corpus appears as stars on the torus it
  designed, and the engine now demonstrably runs on farms that are not Mitch's grid.
- Noted for the record: the garden states the Solidarity Economies Lab includes a
  Hitchhiker participant — the research lane and the lab lane are one thread now.

- **First upload verified end-to-end — and a portability bug caught by the check.**
  Mitch dropped the zip; probe 200, pulled it back like a collaborator would, and the
  entry listing showed `vendor\three.module.min.js` — Windows Compress-Archive writes
  backslash separators, which strict macOS/Linux unzippers read as literal filenames,
  flattening the layout and breaking the import map. Rebuilt with .NET ZipArchive and
  forward-slash entries (`share/build_zip.ps1`, now the one-command rebuild); verified
  14 entries, slashes clean. Re-drop = Mitch. Lesson kept: a bundle meant for other
  people's machines gets *downloaded and opened* as part of shipping it.
