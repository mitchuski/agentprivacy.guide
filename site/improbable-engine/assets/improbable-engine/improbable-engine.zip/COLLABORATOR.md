# run the improbable engine on your own grid

You've picked this up from `mitch.lattice.myth.garden` — it's the **lattice lab improbable
engine**: a Three.js instrument that seats a FedWiki knowledge commons on the 64-vertex
lattice torus, for transmediale 2027's Lattice theme. It runs entirely on your machine,
reads only your own wiki, and sends nothing anywhere.

## What stays the same, what's yours

- **The six strands are the instrument — they don't change.** Five Lattice Labs + the
  knowledge hearth, seated on six axes (`data/labs.json`). Everyone who runs the engine
  plays the same instrument.
- **The field is yours.** `data/wiki-sites.json` lists which wiki sites feed the
  constellation. The copy in this bundle points at Mitch's local farm — replace it with
  your own sites. Your knowledge, same lattice.

## Quickstart (you have node installed)

```
unzip improbable-engine.zip && cd improbable-engine
node serve.mjs           # → http://localhost:4242
```

That alone shows the latent torus. To light it with your knowledge you need a local
FedWiki farm on port 3030:

```
npm install -g wiki
wiki --data ~/.wiki --port 3030 --farm
```

Visit any `http://<name>.localhost:3030` once to birth a site, write some pages, then
list your site hosts in `data/wiki-sites.json` (each with the strand it belongs near)
and refresh :4242. Pages appear as stars; links weave; click-walks trace constellations
you can save and export.

## Or ask your agent

Paste this to Claude (or your agent of choice) from inside the unzipped folder:

> Read COLLABORATOR.md and README.md in this directory. Set up a local FedWiki farm on
> port 3030 for my machine (install the `wiki` npm package if needed), create two or
> three starter sites reflecting my own projects and notes — my grid, not Mitch's —
> then rewrite data/wiki-sites.json to point at my sites with sensible strand
> affinities. Do not edit data/labs.json (the six strands are the fixed instrument).
> Then run `node serve.mjs` and tell me when http://localhost:4242 is alive.

## Orientation

- `README.md` — what the piece is and how the geometry works
- `PLAN_*.md` — the four plans, including the generative hearth (any farm) and the
  overlap/autoresearch loop (two farms, one torus, improbability bridges) — the part
  where your grid and Mitch's meet
- `chronicles/` — the full provenance of how this was built, guide-style
- Everything is read-only toward wikis: the engine never writes to any wiki, and your
  constellation saves live only in your browser's localStorage until you export them.

## The meeting

The point of running your own: two farms can eventually **overlap** on one torus —
shared slugs as twin-stars, an agent autoresearch loop proposing improbable bridges
between your pages and someone else's (see the overlap plan). Bring your grid.

(⚔️⊥⿻⊥🧙)😊
