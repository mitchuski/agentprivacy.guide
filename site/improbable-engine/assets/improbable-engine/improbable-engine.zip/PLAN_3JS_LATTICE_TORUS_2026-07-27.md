# PLAN — the Lattice Torus · Three.js interactive build
2026-07-27 · `~/transmediale` · supersedes the **Form** section of `PLAN_LATTICE_TORUS_2026-07-27.md`
(phases + the ★ localwiki review checkpoint from that plan still stand)

## 0. The geometric direction (why a torus, and why it's not decoration)

Read against the canon — game42 `GEOMETRY.md` / `MODEL-SYNC.md` / `VISUAL-SPEC.md` and the
soulbis `/star` instrument — the transmediale piece is not "a lattice that looks nice on a
torus." It is the **third seating of the same 64-vertex sovereignty lattice**:

| Seating | Surface | What it shows |
|---|---|---|
| `/lattice` (Vertex Codex) | flat 8×8 grid | the lattice as codex — read one vertex at a time |
| `/star` (Star-Tetrahedron Manifold) | spherical harmonic manifold | the lattice as walk — T∫(π), succ/neg/bnot, R(t) shell |
| **transmediale (Lattice Torus)** | **8×8 grid wrapped on a torus** | **the lattice as commons — knowledge shared across it** |

The wrap is exact, not aesthetic: a 6-bit vertex splits into two 3-bit halves →
`(u,v) ∈ 8×8`, and gluing both edges of the 8×8 codex (periodic in u AND v) **is** a torus.
The Vertex Codex was always a torus cut open and laid flat. The transmediale piece closes it.
No boundary row, no privileged corner — the geometry itself performs the theme: a lattice
with no extraction point.

**The six strands = the six stratum-1 roots.** Five labs + the FedWiki Pi knowledge hearth
= six — the same count as the lattice basis (C(6,1) = 6, the load-bearing binding in
MODEL-SYNC §4). Proposed axis mapping **[Conjectural — Mitch confirms or reseats]**:

| Strand | Axis | Hue (game42 canon) | Why |
|---|---|---|---|
| Reclaiming the Interface (Lialina) | protection ⚔️ | amber-gold `#E0A526` | the interface IS the boundary; primary Swordsman |
| Playful Misuse (viola he) | delegation 🧙 | sapphire `#2563EB` | repurposing tools = agency over them; primary Mage |
| Obscure Detritus (Declino) | compute | violet `#7C5CFF` | AI characters, inference, emergent behaviour |
| Minor Indexes (selfservice.studio) | memory | rose `#E0568A` | situated datasets, indexes, archives = continuity |
| Solidarity Economies (Eckenhaussen/Lovink) | value | emerald `#2FB67C` | cooperatives, fair pay = the capital axis |
| **FedWiki Pi knowledge hearth** | **connection 🤝** | teal `#14B8A6` | federation is literally the network axis |

Four of the six are the Four Forces (Protect/Project/Reflect/Connect); the hearth lands on
Connect — emergent from the Mage's delegation patterns, which is exactly what a federated
wiki is. Each strand is drawn as a **(1,1)-style winding** on the torus surface passing
through the vertices where its bit flips, in its axis hue.

**The Three Graphs, in time.** The harvested FedWiki pages are the **Knowledge Graph**
(substrate — what can be shared); the links between pages are the **Promise Graph**; paths
actually walked by a visitor accrue as the **Trust Graph** with a live T∫(π) readout —
value lives on the path, not the vertex, same register as `/star`. The lab program itself
runs Jul 2026 → festival (Jan 26–31 2027): program progress is the fold scalar `p`, and
the festival seal is the boundary hash — boundary encodes bulk, seal on the edges, let the
interior go.

**V6 is present.** The torus carries the moving-ceiling reading as a toggle: a violet
shell (`R(t) = R₀·e^{g·t}`, `t* = ln(1/R₀)/g`) closing on the torus as t runs toward the
festival — a sealed commons is dated, not eternal; re-keying is a first-class move.

**The golden thread.** Ambient drift twists the torus by the golden angle register
(137.50776°) — same φ as the game42 fold and the 61.8/38.2 split. Latent state breathes
per game42 GEOMETRY §5: faint, waiting, one warm call to act.

## 1. Honesty discipline (labels shown in the piece's info panel)

- **Architectural**: 64 = 2⁶ vertices; 8×8 periodic wrap = torus; six stratum-1 roots;
  three-graphs staging; T∫(π) on walked paths; boundary seal; R(t) shelf-life.
- **Conjectural**: the lab↔axis mapping (~resonance, Mitch's call); any 96/64 echo in the
  torus edge count (8×8 torus grid has 128 grid edges — record kinship as resonance, do
  NOT claim the holographic ratio).
- **Aesthetic**: winding style, drift rates, glow, palette presets.

## 2. Three.js architecture

Same species as `/star` (which is already a Three.js single-file instrument):

- **One file: `index.html`.** No build step, no framework. Three.js via import map
  (vendored local copy in `vendor/` so the piece runs offline on the Pi — festival
  installations don't get to assume a CDN). OrbitControls vendored likewise.
- **Scene graph**:
  - `world` → slow golden drift
    - `torusGroup` — the torus body: semi-transparent manifold mesh (custom
      `BufferGeometry`, cool→warm HSL gradient by minor-circle angle, `FogExp2`,
      additive-blend glow sprites for vertices — the `/star` recipe)
    - `latticeGroup` — 64 vertex gems seated at the 8×8 grid points; grid edges as
      faint lines; six strand windings as `TubeGeometry` curves in axis hues
    - `graphGroup` — FedWiki page-stars seated on the surface near their strand
      (cluster→strand affinity), link edges as great-arc curves hugging the surface;
      instanced meshes (`InstancedMesh`) so hundreds of pages stay cheap
    - `hearthGroup` — the Pi hearth at torus centre: white-gold core, teal ring,
      slow pulse, six faint light threads reaching to the six strands (game42's
      ignition-seed motif, re-aimed)
    - `ceilGroup` — the R(t) shell (hidden until toggled)
  - DOM chrome: glass panels, mono eyebrows, serif display title — the `/lattice`
    register; legend chips with glow gems, one per strand, steward names as subtitles.
- **State**: one `state` object + `DEFAULTS`, URL-hash serialisable so a view is shareable.
- **Data**: `data/labs.json` (strands) + `data/graph.json` (harvest output — only after
  the ★ hearth-manifest review). Piece must run fully on `labs.json` alone with a
  placeholder constellation, so the build never blocks on the wiki review.

## 3. Interactions (the "interactive" contract)

1. **Orbit + zoom** — OrbitControls, damped; auto-drift resumes after idle.
2. **Hover a page-star** — title, site, last-edit age; its links brighten.
3. **Click a page-star** — walk to it: camera glides along the surface arc, the traversed
   edge seals into the Trust-Graph trail (brighter, persistent this session), T∫(π)
   accrues in the tracer readout. When running on localhost, click-through opens the
   live wiki page.
4. **Strand isolation** — click a legend chip: that lab's winding + its affine pages
   foreground, rest dims. Second click restores.
5. **Torus ↔ codex fold** — a slider/toggle morphs the torus open into the flat 8×8
   codex and back (linear interpolation of vertex positions between the two seatings —
   the reveal that they are the same object; the piece's signature move).
6. **Read the ceiling** — toggle the R(t) shell with year slider, `/star` semantics.
7. **Latent state** — before first interaction: breath, faint star field, one warm
   hearth pulse as the call to act. `prefers-reduced-motion`: static latent, no drift,
   fold becomes a single eased transition.
8. **Seal card** — a "seal" button renders the current trail as a shareable PNG
   (plan-view torus, six hues, T∫(π) value, lowercase proverb) — game42 VISUAL-SPEC §7.

## 4. Palette & type

Ground `#0B0E14`; the six axis hues above; lens-cyan `#38BDF8` reserved for live-edit
gleams; white-gold core `#F5F0E1`. Four-intelligences presets (nature/human/artificial/
alien) carried over from `/star` as an easter-egg toggle. Type: serif display italic for
the title, mono for labels — run the dataviz skill pass before final hue tuning
(contrast on the dark ground, colour-blind check across six hues).

## 5. Build order

1. **B1 — torus + lattice**: manifold, 64 gems, grid edges, six windings, legend,
   orbit, drift, latent breath. Runs on `labs.json` only.
2. **B2 — the fold**: torus ↔ codex morph slider. (Do early — it constrains how vertex
   positions are stored: always keep both seatings per vertex.)
3. **B3 — hearth + placeholder constellation**: hearth core, threads, ~40 fake
   page-stars to prove seating/instancing/hover.
4. **★ hearth-manifest review** (Mitch, unchanged from plan 1) → `scripts/harvest.mjs`
   → `data/graph.json`.
5. **B4 — real graph**: seat harvest, walk mechanic, T∫(π) tracer, trail persistence,
   click-through to localhost wiki.
6. **B5 — ceiling + seal card + reduced-motion + URL-hash state.**
7. **B6 — polish pass**: dataviz skill check, perf (instancing, `pixelRatio` cap 2),
   Pi test (it should run on the hearth itself — that's the point).

No git / no deploy without explicit ask.

> the codex was a torus all along; it only needed enough sharing to close

(⚔️⊥⿻⊥🧙)😊
