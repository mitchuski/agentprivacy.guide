// serve.mjs — zero-dependency local server for the Lattice Torus demo.
//   node serve.mjs            → http://localhost:4242
// Serves this directory statically, and proxies  /wiki/<host>/<path>
// to the local FedWiki farm at 127.0.0.1:3030 with the vhost Host header,
// so the page never needs CORS and nothing leaves the machine.
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = fileURLToPath(new URL('.', import.meta.url));
const PORT = Number(process.env.PORT || 4242);
const FARM = { host: '127.0.0.1', port: Number(process.env.FARM_PORT || 3030) };
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml',
  '.md': 'text/markdown; charset=utf-8', '.woff2': 'font/woff2'
};

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  // ---- wiki proxy: /wiki/<vhost>/<path...> → farm with Host header ----
  const m = url.pathname.match(/^\/wiki\/([a-z0-9.-]+)\/(.*)$/);
  if (m) {
    const [, vhost, rest] = m;
    if (!vhost.endsWith('.localhost') && vhost !== 'localhost') {
      res.writeHead(403).end('only *.localhost vhosts are proxied'); return;
    }
    const preq = http.request(
      { host: FARM.host, port: FARM.port, path: '/' + rest + url.search, method: 'GET',
        headers: { Host: vhost + ':' + FARM.port, Accept: 'application/json' } },
      pres => { res.writeHead(pres.statusCode, { 'content-type': pres.headers['content-type'] || 'application/json' }); pres.pipe(res); });
    preq.on('error', () => { res.writeHead(502, { 'content-type': 'application/json' })
      .end(JSON.stringify({ error: 'farm unreachable', hint: 'wiki --data ~/.wiki --port 3030 --farm' })); });
    preq.end(); return;
  }
  // ---- static files ----
  let p = normalize(decodeURIComponent(url.pathname)).replace(/^([/\\])+/, '');
  if (p === '' || p === '.') p = 'index.html';
  const file = join(ROOT, p);
  if (!file.startsWith(ROOT)) { res.writeHead(403).end(); return; }
  try {
    const body = await readFile(file);
    res.writeHead(200, { 'content-type': MIME[extname(file).toLowerCase()] || 'application/octet-stream' }).end(body);
  } catch { res.writeHead(404).end('not found'); }
});

server.listen(PORT, '127.0.0.1', () =>
  console.log(`lattice torus → http://localhost:${PORT}  (farm proxy → ${FARM.host}:${FARM.port})`));
