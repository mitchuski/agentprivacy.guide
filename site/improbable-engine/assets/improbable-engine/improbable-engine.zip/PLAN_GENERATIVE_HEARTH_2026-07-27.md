# PLAN — the Generative Hearth · any farm can feed the engine
2026-07-27 · `~/transmediale` · extends the 3js plan; companion to `PLAN_OVERLAP_AUTORESEARCH_2026-07-27.md`

## The observation that started this

The demo auto-generated its constellation from Mitch's local farm — the agentprivacy
universe. That was one config file. The realisation: **nothing about the engine is
specific to that farm.** Any FedWiki farm has the same shape (sites → sitemaps → pages →
links), so the field should be *generative*: someone hosts their own farm, points the
engine at it, and gets *their* lattice torus — their knowledge, seated on the six strands,
without hand-editing JSON.

## What changes

### G1 — the hearth field (UI, replaces hand-edited config as the entry path)
- A "hearth" input on the instrument: paste a farm root (`http://localhost:3030`,
  `https://wiki.example.org`, a `*.fed.wiki` domain…) or accept the local default.
- **Site discovery.** For a farm root, discover its sites rather than demand a list:
  try the farm's own registry endpoints (`/view/welcome-visitors` roster page, or the
  known-sites convention), fall back to a single-site read, and let the visitor add
  site hosts manually. Discovery results are shown as a checklist — **the visitor's
  manifest moment**, the same consent gesture as Mitch's ★ review, made first-class UI.
- **Transport.** Remote FedWikis serve JSON with permissive CORS (federation depends on
  it) → direct browser fetch. Local vhost farms (`*.localhost`) keep the `serve.mjs`
  proxy. One `fetchWiki(farm, host, path)` that picks the path.
- Config persists in localStorage; `data/wiki-sites.json` remains as the seeded default
  (Mitch's hearth) and as the file-based override.

### G2 — generative strand affinity (the auto-seating)
Today each site is hand-assigned a strand. Generatively, the engine seats content itself:

- **Lexicon scoring (v1, no model needed).** Each strand carries a small lexicon derived
  from its lab theme + axis (e.g. memory/Minor Indexes: *index, archive, dataset,
  catalog, record, collection*; value/Solidarity: *coop, fund, pay, economy, commons,
  budget*…). Score each page's title+synopsis against the six lexicons; the site's
  affinity = argmax of its pages' aggregate, pages may individually defect to a
  different strand when their own score is decisive. Ties/low-signal → connection (the
  hearth strand is the honest default: "this is shared knowledge, axis undetermined").
- **Embedding scoring (v2, optional).** Same seating decision, cosine similarity of
  page synopsis vs strand descriptions, via a tiny local embedding step — never a
  hosted API by default; the engine must stay runnable on a Pi with no keys.
- The affinity report is **shown, not silent**: a "seating" panel lists what went where
  and why (top terms), and every assignment is draggable to another strand — generative
  proposes, the human seats. (Same honesty discipline as the lab↔axis mapping:
  auto-affinity is Conjectural by construction.)
- `data/strand-lexicons.json` — the six lexicons, editable, versioned with the piece.

### G3 — the strands stay, the field varies
The six strands (five labs + hearth) are the *fixed instrument*; visiting farms are the
*variable field* played on it. That's the artwork's statement at transmediale: bring your
commons, see it take the shape of the lattice. A visitor never edits labs.json — they
bring pages, not axes.

## Privacy posture (non-negotiable)
- Read-only, always. The engine never writes to any wiki.
- The engine renders only what a farm already publishes (sitemaps are public artifacts
  of FedWiki). Still: the site checklist is opt-in per site, nothing pre-checked for
  remote farms, and no farm URL is ever sent anywhere except to that farm itself.
- No analytics, no beacons; constellation saves stay in the visitor's localStorage
  unless they export the file themselves.

## Build order
1. `fetchWiki` transport split (proxy vs direct) + farm-root input + manual site add.
2. Site checklist UI → replaces static config path (config file still honored).
3. `data/strand-lexicons.json` + lexicon scorer + seating panel with manual reseat.
4. Persist per-farm config in localStorage; "reset to Mitch's hearth" affordance.
5. (v2, later) local embedding scorer behind the same seating interface.

(⚔️⊥⿻⊥🧙)😊
