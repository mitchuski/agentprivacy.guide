# the lattice lab improbable engine

**transmediale 2027 · Lattice Labs × the FedWiki knowledge hearth** — the third seating of
the 64-vertex sovereignty lattice: `/lattice` reads it flat (the codex), `/star` walks it
(the manifold), this piece **closes it** (an 8×8 grid periodic in both directions is a
torus — no boundary row, no privileged corner, a lattice with no extraction point).

Six strands wind the surface — the five Lattice Labs plus the FedWiki π hearth, seated on
the six stratum-1 roots with their game42 axis hues (`data/labs.json`; the seating is
**conjectural**, pending review). Live pages from the local wiki farm are stars near their
strand; sitemap links weave the Promise Graph; the paths you click-walk accrue as the
Trust Graph with a T∫(π) tracer. Value lives on the path, not the vertex.

## Run it

```
# 1. the hearth (if not already burning)
wiki --data ~/.wiki --port 3030 --farm

# 2. the torus
cd ~/transmediale
npm run dev          # → http://localhost:4242
```

The page runs latent (torus, strands, hearth, breath) even with the farm asleep;
with the farm up it seats the live pages of the sites in `data/wiki-sites.json` —
the **proto hearth-manifest**, edit it freely. Everything is read live and locally;
nothing is harvested to disk, nothing leaves the machine.

## The instrument

- **orbit / zoom** — drag, wheel (damped; slow golden drift when idle)
- **torus ⇄ codex** — the fold slider morphs the closed lattice open into the flat 8×8
  Vertex Codex and back: the reveal that they are the same object
- **legend chips** — click to isolate a strand and its pages
- **page-stars** — hover for title · click to **walk** (T∫(π) accrues, trail seals) ·
  shift+click opens the page in the wiki
- **constellations** — ✦ save names the current walk (localStorage), click a saved name
  to relight it, ⬇ export downloads them all as `constellations.json`
- pages edited in the last 7 days pulse

## Files

- `index.html` — the whole instrument (single file, ES modules, no build step)
- `vendor/` — three@0.161.0 + OrbitControls, vendored so it runs offline / on the Pi
- `serve.mjs` — zero-dep static server + `/wiki/<host>/<path>` proxy to the farm (no CORS)
- `data/labs.json` — the six strands · `data/wiki-sites.json` — proto-manifest
- `PLAN_LATTICE_TORUS_2026-07-27.md` · `PLAN_3JS_LATTICE_TORUS_2026-07-27.md` — the plans
- `PLAN_GENERATIVE_HEARTH_2026-07-27.md` — any farm can feed the engine (site discovery,
  generative strand seating) · `PLAN_OVERLAP_AUTORESEARCH_2026-07-27.md` — overlap two
  farms, agent autoresearch loop, improbability bridges
- `chronicles/` — the build's provenance, written as it happened

> the codex was a torus all along; it only needed enough sharing to close

(⚔️⊥⿻⊥🧙)😊
