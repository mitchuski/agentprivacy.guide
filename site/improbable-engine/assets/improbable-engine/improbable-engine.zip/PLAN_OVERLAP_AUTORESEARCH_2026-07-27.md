# PLAN — Overlap & the Autoresearch Loop · why it's called the improbable engine
2026-07-27 · `~/transmediale` · companion to `PLAN_GENERATIVE_HEARTH_2026-07-27.md`

## The idea

Once any farm can feed the engine (generative hearth), two farms can feed it **at once**.
The piece then stops being a portrait of one commons and becomes an instrument for
**meeting**: overlap your farm with mine, and let an agent research the space between —
connect the dots neither of us drew, and render the result as a new constellation.

The name earns itself here. In FedWiki, knowledge travels by forking; two farms that
share a slug share a lineage. But the *interesting* connections — the ones worth a
festival — are the **improbable** ones: pages that never forked each other, never linked,
yet answer each other. An engine whose job is to find and light the least-probable
bridges between two knowledge fields is an **improbability engine** in the honest
Hitchhiker's sense: it doesn't make the improbable happen, it makes it *visible*, and
navigation is identity (constellation evocation — you prove the connection by walking it).

## Part 1 — Overlap (two+ farms, one torus)

- **Loading.** N farms (start with 2), each with its own site checklist per the
  generative-hearth plan. Farm A seats its stars with lift-band `[0.05, 0.14]`, farm B
  with `[0.16, 0.25]` — two constellation shells over the same lattice, distinguishable
  by altitude and by a per-farm sprite shape (dot vs ring), NOT by hue (hue belongs to
  the strands).
- **Native overlap: shared slugs.** FedWiki's own identity: same slug across farms =
  same page-lineage (fork family). Render as a **twin-star**: the two stars drawn at
  their own shells with a bright white vertical filament joining them — the federation's
  fork lines made literal. The journal's fork entries, when present, give directionality.
- **Overlap index.** A panel readout: shared slugs, shared link-targets, per-strand
  overlap density — the two commons' resonance profile across the six axes. (Which axes
  do our farms already agree on? Where do we not touch at all?)
- **Consent.** Overlap is symmetric exposure: both parties see both farms' titles.
  Both farm manifests must be explicitly loaded in the same session; the engine never
  remembers someone else's farm beyond the session unless saved deliberately.

## Part 2 — the Autoresearch Loop (the agent that connects the dots)

An agent walks both farms and researches the gap between them. Strictly **read the wikis,
write only its own report** — the loop's output is a JSON artifact the engine renders;
it never edits anyone's wiki.

- **Loop shape** (runs outside the page — a script/agent session; the page only renders):
  1. **Sweep** — read both farms' sitemaps + selected page stories.
  2. **Connect** — find candidate bridges: semantic kinship between page A (farm 1) and
     page B (farm 2) that are *not* already linked and *not* the same slug. Score by
     kinship ÷ prior-connectedness — **the improbability score**: high kinship between
     otherwise-distant regions ranks first. (Lexicon/embedding kinship per the
     generative-hearth scorers; graph distance from the woven Promise Graph.)
  3. **Propose** — for each surviving bridge, the agent writes one honest sentence:
     *why these two pages answer each other*, plus the evidence trail (which story
     items). No sentence, no bridge — the reason is the artifact.
  4. **Verify** — a second pass adversarially prunes: would a reader who opened both
     pages accept the sentence? Kill weak bridges (the register wins over the vibe).
  5. **Emit** — `data/bridges-<a>×<b>-<date>.json`:
     `{farms, generated, bridges:[{from:{host,slug}, to:{host,slug}, score, reason, evidence}]}`
- **Rendering.** Bridges draw as a distinct layer — improbability arcs in a hue no
  strand owns (the ceiling's violet family suggests itself: the third thing, neither
  sword nor mage), width/glow by score, hover shows the agent's reason sentence.
  Together the bridges + the twin-stars **are** a new visualisation: the constellation
  of the meeting, saveable/exportable exactly like a walked constellation.
- **The human step.** A rendered bridge is a *proposal*. Accepting one — actually
  linking the pages in a wiki — is a human act on their own farm, outside the engine.
  (The agent proposes the improbable; the person promises. Promise Theory's autonomy
  axiom, kept: no one promises on another's behalf.)

## Honesty & governance
- Bridge scores and auto-affinities: **Conjectural by construction**, labeled in-UI.
- The loop must run fully local (local farms + local model or lexicon scorer) — a Pi
  and a laptop in a room at the festival is the reference deployment: two people, two
  farms, one overlap, twenty minutes.
- No wiki writes by the agent, ever; report files only. No farm data leaves the machines
  the farms are on, except the bridge report the two parties generate together.

## Build order
1. Multi-farm loading + shells + twin-star filaments (shared slugs).
2. Overlap index panel.
3. Bridge JSON schema + a hand-authored sample file + the rendering layer
   (render before the agent exists — the format is the contract).
4. `scripts/autoresearch.mjs` v1: sweep + lexicon kinship + improbability score +
   reason sentences (template-honest), emit report.
5. v2: agent-grade reasons + adversarial verify pass (Claude session or local model).
6. Festival choreography: the two-visitor ceremony (load, overlap, run, walk the
   bridges, save the constellation, export — each leaves with the file).

(⚔️⊥⿻⊥🧙)😊
